package br.com.artuxsouto.meusprojetos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeusprojetosApplicationTests {

	@Test
	void contextLoads() {
	}

}
